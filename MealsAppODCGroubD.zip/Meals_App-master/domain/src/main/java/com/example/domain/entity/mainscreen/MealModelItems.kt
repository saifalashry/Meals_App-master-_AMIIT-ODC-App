package com.example.domain.entity.mainscreen

data class MealModelItems(
    val categories: List<Category>
)